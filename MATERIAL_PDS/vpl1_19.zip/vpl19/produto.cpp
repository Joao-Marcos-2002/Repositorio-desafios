#include "produto.hpp"

int Produto::getQtd() const {
  return m_qtd;
}

float Produto::getValor() const {
  return m_valor_unitario;
}