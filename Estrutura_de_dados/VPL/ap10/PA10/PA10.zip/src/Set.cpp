#include <iostream>
#include "../include/Set.hpp"

StringSet::StringSet(int tamanho) {
        /* define o tamanhoOriginal e inicializa o tamanho
         da tabela como o dobro. */
        tamanhoOriginal = tamanho;
        tamanhoTabela = 2 * tamanhoOriginal;

        tamanhoConjunto = 0;    
        tabela = new ElementoTabela[tamanhoTabela];
    }

StringSet::~StringSet() {
        // libera memoria alocada.
        delete[] tabela;
    }

void StringSet::Inserir(string s) {
    // Pega o hash da string.
    int p = Hash(s);
    int tam = tamanhoTabela;

    //testa se a posicao esta ocupada e trata a colisao.
    while(!tabela[p].vazio && !tabela[p].retirada) {
        p = (1 + p) % tam;
    }

    //Deve-se inserir na posicao vazia.
    tabela[p].retirada = false;
    tabela[p].vazio = false;
    tabela[p].dado = s;

    //atualiza o tam
    tamanhoConjunto++;
    int tamConj = static_cast<double>(tamanhoConjunto);

    // Testa se precisa de rehash
    if (tamConj / tamanhoTabela > 0.7) {
        Resize(tamanhoTabela * 2);
    }

}

void StringSet::Remover(string s) {
    int p = Hash(s);

    // Verifica se a string 's' está no set e se nao esta vazia.
    if(tabela[p].retirada || tabela[p].vazio || tabela[p].dado != s) {
        return;
    }

    tabela[p].retirada = true;

    //tamanho do conjunto decresce.
    tamanhoConjunto--;

    // caso necessario redimensiona a tabela.
    if(tamanhoConjunto < tamanhoOriginal / 4) {
        Resize(tamanhoOriginal / 2);
    }

}

bool StringSet::Pertence(string s) {
    // pega a posicao do hash.
    int p = Hash(s);

    // Verifica se a posicao nao esta vazia  e se o elemento nao foi removido
    if(!tabela[p].vazio && !tabela[p].retirada) {
        // compara se o elemento esta armazenado na posicao.
        if(tabela[p].dado == s) {
            return true;
        }
    }

     return false;   
}

StringSet* StringSet::Intersecao(StringSet* s) {
    // cria um conjunto para armazenar a interseccao.
    StringSet* resultadoInter = new StringSet(tamanhoOriginal);

    for (int i = 0; i < tamanhoTabela; i++) {
        if (!tabela[i].vazio && !tabela[i].retirada) {
            if (s->Pertence(tabela[i].dado)) {
                //insere o elemento na interseccao.
                resultadoInter->Inserir(tabela[i].dado);
            }
        }
    }
    return resultadoInter;
}

StringSet* StringSet::Uniao(StringSet* s) {
    StringSet* uniaoSet = new StringSet(tamanhoOriginal);

    for (int i = 0; i < tamanhoTabela; i++) {
        if(!tabela[i].vazio && !tabela[i].retirada) {
            uniaoSet->Inserir(tabela[i].dado);
        }
    }

    for(int i = 0; i < tamanhoTabela; i++) {
        if(!s->tabela[i].vazio && !s->tabela[i].retirada) {
            uniaoSet->Inserir(s->tabela[i].dado);
        }
    }

    return uniaoSet;
}

// Uniao - intersecao
StringSet* StringSet::DiferencaSimetrica(StringSet* s) {
    // Cria um conjunto para armazenar a diferença simetrica
     StringSet* diferencaSet = new StringSet(tamanhoTabela);

     for(int i = 0; i < tamanhoTabela; i++) {
        if(!tabela[i].vazio && !tabela[i].retirada) {
            // Adiciona elementos que estao no primeiro conjunto e nao no segundo.
            if(!s->Pertence(tabela[i].dado)) {
                diferencaSet->Inserir(tabela[i].dado);
            }
        }
     }

     for(int i = 0; i < s->tamanhoTabela; i++) {
        if(!s->tabela[i].vazio && !s->tabela[i].retirada) {
            // Adiciona elementos que estao no segundo e nao no primeiro.
            if(!Pertence(s->tabela[i].dado)) {
                diferencaSet->Inserir(s->tabela[i].dado);
            }
        }
     }

     return diferencaSet;
}

// Imprime os dados na tela.
void StringSet::Imprimir() {
    // cout << "Conjunto: { ";

    for (int i = 0; i < tamanhoTabela; ++i) {
        if (!tabela[i].vazio && !tabela[i].retirada) {
            cout << tabela[i].dado << " ";
        }
    }

    // cout << "}" << endl;
}


int StringSet::Hash(string s) {
    int hash = 0;

    for (char c : s) {
        hash += static_cast<int>(c);
    }

    hash %= tamanhoTabela;

    // retorna o indice que foi calculado
    return hash;
}

void StringSet::Rehash(int pos) {
    int posOriginal = pos;
    int tentativa = 1;

    while (!tabela[pos].vazio && !tabela[pos].retirada) {
        // Aplicar sondagem linear: vá para o próximo slot
        pos = (posOriginal + tentativa) % tamanhoTabela;
        tentativa++;
    }
}

void StringSet::Resize(size_t tamanho) {
    ElementoTabela* novaTabela = new ElementoTabela[tamanho];

    tamanhoTabela = tamanho;

    for(int i = 0; i < tamanhoOriginal; i++) {
        if(!tabela[i].vazio && !tabela[i].retirada) {
            int pos = Hash(tabela[i].dado);
            Rehash(pos);

            novaTabela[pos] = tabela[i];
        }
    }

    // libera a memoria da tabela antiga
    delete[] tabela;
    //atualiza a tabela para apontar para a nova tabela mencionada.
    tabela = novaTabela;

}