// #ifndef SEGTREE_HPP
// #define SEGTREE_HPP


// class Segtree {
//     public:
//         long long m11, m12, m21, m22;
//         int first;
//         int second;

//         // Construtor
//         Segtree(int f, int s) : first(f), second(s) {}

//         Segtree(long long a, long long b, long long c, long long d);
//         Segtree();
//         ~Segtree();
//         int build(int p, int l, int r);
//         Segtree update(int i, int x, int p, int l, int r);
//         Segtree query(int a, int b, int p, int l, int r);
//         Segtree associarTransformacao(Segtree a, Segtree b);
//         Segtree combina(Segtree a, Segtree b);

//     private:
//     static const int maxSize = 1000;  // tamanho máximo desejado
//     // int vet[maxSize];
//     // int tree[4 * maxSize];

//     int vet[maxSize][maxSize];
//     int tree[4*maxSize][4*maxSize];

   

// };





// #endif


#ifndef SEGTREE_HPP
#define SEGTREE_HPP

// #include "matriz.hpp"


struct Matrix2x2 {
    int m11, m12, m21, m22;
    int first;
    int second;

    // Construtor
    Matrix2x2(long long a, long long b, long long c, long long d) : m11(a), m12(b), m21(c), m22(d) {}

    // Construtor padrão.
    Matrix2x2() : m11(0), m12(0), m21(0), m22(0) {}
};

class Segtree {
public:
    long long m11, m12, m21, m22;
    int first;
    int second;

    // Construtor
    Segtree(int f, int s) : first(f), second(s) {}

    Segtree(long long a, long long b, long long c, long long d);
    Segtree();
    ~Segtree();
    Matrix2x2 build(int p, int l, int r);
    Matrix2x2 update(int i, int x, int p, int l, int r);
    Matrix2x2 query(int a, int b, int p, int l, int r);
    Matrix2x2 multMatrizes(Matrix2x2 a, Matrix2x2 b);
    Matrix2x2 combina(Matrix2x2 a, Matrix2x2 b);

private:
    static const int maxSize = 1000;  
    Matrix2x2 vet[maxSize];
    Matrix2x2 tree[4 * maxSize][4 * maxSize];
    Matrix2x2 v[maxSize];
};

#endif
