// #include "avl_tree.hpp"
// #include <iostream>

// using namespace std;

// Node::Node(int k) : key(k), height(1), left(nullptr), rigth(nullptr) {}

// int heigth(Node* node) {
//     if(node == nullptr) return 0;
//     return node->height;
// }


