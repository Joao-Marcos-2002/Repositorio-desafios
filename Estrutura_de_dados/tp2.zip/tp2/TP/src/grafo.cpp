#include <iostream>

#include "../include/grafo.hpp"
using namespace std;


Grafo::Grafo(int n) {
    vertices.resize(n);
}

void Grafo::lerEntrada() {
    int qtdVertices;
    char tipoEntrada;

    // Lê o tipo de entrada (p ou outra coisa)
    cin >> tipoEntrada;

    
    cin >> tipoEntrada;


   
if (tipoEntrada == 'q') {
        // If the sorting algorithm is 'q' (quick sort), read the number of vertices separately
        cin >> qtdVertices;
    } else {
        // For other sorting algorithms, read the number of vertices on the same line
        qtdVertices = tipoEntrada - '0';  // Convert the character to an integer
        vertices.clear();
        vertices.resize(qtdVertices);
    }

    for (int i = 0; i < qtdVertices; i++) {
        // lê a vizinhança de cada vértice.
        int qtdVizinhos, qtdV, qtd;
        cin >> qtdVizinhos;

        
        cin >> qtdV;

        cin >> qtd;

       
    for (int j = 0; j < qtdVizinhos; j++) {
            int adjcVertice;
            cin >> adjcVertice;

            if (adjcVertice == 1)
                vertices[i].vizinhos.push_back(adjcVertice);
        }

        // Faz a leitura da cor do vértice.
        int corEscolhida;
        cin >> corEscolhida;
        vertices[i].cor = corEscolhida;
    }
}

// void Grafo::lerEntrada() {
//     int qtdVertices;
//     char tipoEntrada;

//     // Lê o tipo de entrada (p ou outra coisa)
//     cin >> tipoEntrada >> qtdVertices;
//     vertices.clear();
//     vertices.resize(qtdVertices);

//     for (int i = 0; i < qtdVertices; i++) {
//         // lê a vizinhança de cada vértice.
//         int qtdVizinhos;
//         cin >> qtdVizinhos;

//         for (int j = 0; j < qtdVizinhos; j++) {
//             int adjcVertice;
//             cin >> adjcVertice;

//             if (adjcVertice == 1)
//                 vertices[i].vizinhos.push_back(adjcVertice); 
//         }

//         // Faz a leitura da cor do vértice.
//         int corEscolhida;
//         cin >> corEscolhida;
//         vertices[i].cor = corEscolhida;
//     }
// }

// void Grafo::lerEntrada() {
//     int qtdVertices;
//     char tipoEntrada;

//     // Lê o tipo de entrada (p ou outra coisa)
//     cin >> tipoEntrada >> qtdVertices;
//     vertices.clear();
//     vertices.resize(qtdVertices);

//     for (int i = 0; i < qtdVertices; i++) {
//         // lê a vizinhança de cada vértice.
//         int qtdVizinhos;
//         cin >> qtdVizinhos;

//         for (int j = 0; j < qtdVizinhos; j++) {
//             int adjcVertice;
//             cin >> adjcVertice;

//             if (adjcVertice == 1)
//                 vertices[i].vizinhos.push_back(j);
//         }

//         // Faz a leitura da cor do vértice.
//         int corEscolhida;
//         cin >> corEscolhida;
//         vertices[i].cor = corEscolhida;
//     }
// }




// Avalia se possui coloracao gulosa
bool Grafo::avaliarColoracaoGulosa() {
    int qtdVertices = vertices.size();

    for (int i = 0; i < qtdVertices; i++) {
        int corAtual = vertices[i].cor;

        for (int vizinho : vertices[i].vizinhos) {
            int corVizinhos = vertices[vizinho].cor;

            // verifica se a coloracao eh valida
            if (corAtual == corVizinhos) {
                return false;
            }
        }
    }
    return true;
}

//retorna os vertices do grafo
vector<Vertice>& Grafo::getVertices() {
    return vertices;
}

