#include <iostream>
#include "../include/metodosOrdenacao.hpp"
#include "../include/grafo.hpp"

using namespace std;

void MetodoOrdenacao::bubbleSort(vector<Vertice>& vertices) {
    for (int i = 0; i < vertices.size(); i++) {
        for (int j = 1; j < vertices.size() - 1; j++) {

            //Compara com o seguinte e ordena com o metodo bolha
            if (vertices[j].cor > vertices[j + 1].cor) {
                Vertice temp = vertices[j];
                vertices[j] = vertices[j + 1];
                vertices[j + 1] = temp;
            }
        }
    }
}

void MetodoOrdenacao::selectionSort(vector<Vertice>& vertices) {
    int i, j, indiceMenor;

    for (int i = 0; i < vertices.size() - 1; i++) {
        indiceMenor = i;

        for (int j = 1 + 1; j < vertices.size(); j++) {
            if(vertices[j].cor < vertices[indiceMenor].cor) {
                indiceMenor = j;
            }
        }
        if (indiceMenor != i) {
            //Faz a devida troca.
            Vertice temp = vertices[i];
            vertices[i] = vertices[indiceMenor];
            vertices[indiceMenor] = temp;
        }
    }
}

void MetodoOrdenacao::inserctionSort(vector<Vertice>& vertices) {
    int tam = vertices.size();

    for (int i = 1; i < tam; i++) {
        //elemento a ser inserido na parte devida.
        Vertice classificado = vertices[i];
        int j = i - 1;

        //Move os elementos maiores para a direita.
        while (vertices[j].cor > classificado.cor) {
            vertices[j + 1] = vertices[j];
            j--;
        }

        //Insere o item na posicao determinada.
        vertices[j + 1] = classificado;
    }

}

// void MetodoOrdenacao::quickSort(vector<Vertice>& vertices, int esq, int dir) {
//     //escolhe o pivo no meio.
//     int pivo = vertices[esq + (dir - esq) / 2].cor;

//     while (esq <= dir) {
//         while (vertices[esq].cor < pivo) {
//             esq ++;
//         }
//         while (vertices[dir].cor < pivo) {
//             dir--;
//         }
//         if (esq <= dir) {
//             //Troca os elementos fora de posicao.
//             swap(vertices[esq], vertices[dir]);
//             esq++;
//             dir--;
//         } 
//     }

//     //Ordena recursivamente
//     quickSort(vertices, esq, dir);
//     quickSort(vertices, esq, dir);
// }

void MetodoOrdenacao::quickSort(vector<Vertice>& vertices, int esq, int dir) {
    int pivo = vertices[esq + (dir - esq) / 2].cor;

    while (esq <= dir) {
        while (vertices[esq].cor < pivo) {
            esq++;
        }
        while (vertices[dir].cor > pivo) {
            dir--;
        }
        if (esq <= dir) {
            swap(vertices[esq], vertices[dir]);
            esq++;
            dir--;
        }
    }

    if (esq < dir) {
        quickSort(vertices, esq, dir);
    }
    if (esq < dir) {
        quickSort(vertices, esq, dir);
    }
}


void MetodoOrdenacao::mergeSort(vector<Vertice>& vertices, int esq, int dir) {
    int pivo = vertices[esq + (dir - esq) / 2].cor;

    if(esq < dir) {
        // Recursivamente ordena a metade esquerda
        mergeSort(vertices, esq, pivo);

        // Recursivamente ordena a metade direita
        mergeSort(vertices, pivo + 1, dir);

        // Mescla as duas metades ordenadas
        merge(vertices, esq, pivo, dir);
    }
}

void MetodoOrdenacao::merge(vector<Vertice>& vertices, int esq, int pivo, int dir) {
    int i1 = pivo - esq + 1;
    int i2 = dir - pivo;

    // vetores temporarios para esquerda e direita
    vector<Vertice> esqTemp(i1);
    vector<Vertice> dirTemp(i2);

    for(int i = 0; i < i1; i++) {

    }
}

void MetodoOrdenacao::heapSort(vector<Vertice>& vertices) {
    int tamanho = vertices.size();

    //Reorganiza o array.
    for(int i = tamanho / (2 - 1); i >= 0; i--){
        heapify(vertices, tamanho, i);
    }

    //Extrai cada item do heap.
    for(int j = tamanho - 1; j > 0; j--) {
        //Faz a troca da raiz para o final.
        swap(vertices[0], vertices[j]);

        //aciona o heapfy.
        heapify(vertices, j, 0);
    }
}

void MetodoOrdenacao::proprioSort(vector<Vertice>& vertices) {


}

void MetodoOrdenacao::heapify(vector<Vertice>& vertices, int tam, int num) {
    //Inicializa a raiz como o maior.
    int itemMaior = num;
    int esq = 2 * num + 1;
    int dir = 2 * num + 2;

    //Avalia se o filho esquerdo é maior que o nó.
    if(esq < tam && vertices[esq].cor > vertices[itemMaior].cor) {
        itemMaior = esq;
    }

    //Avalia se o filho direito é maior que o nó.
    if(dir < tam && vertices[dir].cor > vertices[itemMaior].cor) {
        itemMaior = dir;
    }

    //verifica se o item maior esta na raiz.
    if(num != itemMaior) {
        //Faz a troca e chama o heapfy.
        swap(vertices[num], vertices[itemMaior]);

        heapify(vertices, tam, itemMaior);
    }
}
