#ifndef METODOS_ORDENACAO_HPP
#define METODOS_ORDENACAO_HPP

#include "grafo.hpp"
using namespace std;

class MetodoOrdenacao {
public:
    static void bubbleSort(vector<Vertice>& vertices);
    static void selectionSort(vector<Vertice>& vertices);
    static void inserctionSort(vector<Vertice>& vertices);
    static void quickSort(vector<Vertice>& vertices, int esq, int dir);
    static void mergeSort(vector<Vertice>& vertices, int esq, int dir);
    static void heapSort(vector<Vertice>& vertices);
    static void proprioSort(vector<Vertice>& vertices);
    static void heapify(vector<Vertice>& vertices, int tam, int num);
    static void merge(vector<Vertice>& vertices, int esq, int pivo, int dir);
};

#endif
