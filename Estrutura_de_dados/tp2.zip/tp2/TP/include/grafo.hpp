#ifndef GRAFO_HPP
#define GRAFO_HPP

#include <vector>

using namespace std;

struct Vertice {
    int cor;
    vector<int> vizinhos;
};

class Grafo {
    public:
        Grafo(int n);
        void lerEntrada();
        bool avaliarColoracaoGulosa();
        vector<Vertice>& getVertices();

    private:
        vector<Vertice> vertices;
};


#endif