#ifndef FIB
#define FIB

#include <stdio.h>


int fibonacciRec(int n);
void fibonacciIter();


#endif