#ifndef FAT
#define FAT

#include <stdio.h>

int fatorialIter(int n);
int fatorialRec(int n);


#endif