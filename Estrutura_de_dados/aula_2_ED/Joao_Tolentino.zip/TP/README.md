//---------------------------------------------------------------------
// Arquivo      : README
// Conteudo     : documentacao da aplicacao: TP 
// Autor        : Joao Marcos R. Tolentino
// Historico    : 2023-08-31 - arquivo criado
//---------------------------------------------------------------------



# Fatorial:

Para selecionar essa opção deve-se digitar 1.

De forma recursiva: é apresentado a sequência do fatorial apresentada na faixa de valores entre e 1 e 12. 


Ex:

Digite o fatorial de 10:

O programa basicamente vai calcular: 10! = 3628800


# Sequência de Fibonacci:

Para selecionar essa opção deve-se digitar 1.

De maneira iterativa o programa vai calcular e retornar a sequência até o enésimo termo digitado.

** é informado a faixa de valores calculado para tal: de 1 a 46.



Ex: 

Sequência de fibonacci para o décimo termo:

1
1
2
3
5
8
13
21
34
55



===================================================================================

ESPECIFICAÇÕES MAKEFILE:



Execute o comando "make run" para executar o programa
Execute o comando "make gprof" para gerar os resultados do gprof.



===================================================================================


Relatório detalhado em pdf está na estrutura do projeto como segue:

-TP
 -bin
 -include -> arquivos* .h
 -obj
 -src -> main.cpp
 Makefile
 README.MD
 Relatorio_Joao_Marcos.pdf


