#ifndef SATISFABILIDADE_HPP
#define SATISFABILIDADE_HPP

using namespace std;

    //Aciona funcao de satisfabilidade
    string satisfabilidade(const char *exp, const char *valor);

#endif