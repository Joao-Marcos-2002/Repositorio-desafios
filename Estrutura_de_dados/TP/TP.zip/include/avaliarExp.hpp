#ifndef AVALIAREXP_HPP
#define AVALIAREXP_HPP



using namespace std;

    // Aciona operacao que avalia as operacoes
    int avaliarExpressao(const char *exp, const char *valor);


#endif